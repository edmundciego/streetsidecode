<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;

class UploadImagesToS3 extends Command
{
    protected $signature = 'upload:images-to-s3';
    protected $description = 'Upload all images from local storage to S3 bucket';

    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        $localDisk = Storage::disk('public');
        $s3Disk = Storage::disk('s3');

        $files = $localDisk->allFiles();

        if (empty($files)) {
            $this->info('No images found in local storage.');
            return;
        }

        // Display the list of local files to be uploaded
        $this->info('Images to be uploaded:');
        foreach ($files as $file) {
            $this->line($file);
        }

        // Upload files to S3
        foreach ($files as $file) {
            $fileContents = $localDisk->get($file);
            $s3Disk->put($file, $fileContents);
            $this->info("Uploaded: {$file}");
        }

        // List all files in the S3 'public' directory and its subdirectories
        $s3Files = $s3Disk->allFiles();
        if (empty($s3Files)) {
            $this->error('No images found in S3 storage.');
            return;
        }

        // Display the list of files in S3
        $this->info('Images in S3 storage:');
        foreach ($s3Files as $file) {
            $this->line($file);
        }

        $this->info('All images have been uploaded to S3.');
    }
}
