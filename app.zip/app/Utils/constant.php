<?php
const DEFAULT_DATA_LIMIT= 'all';
const URI = 'uri';
const VIEW = 'view';
