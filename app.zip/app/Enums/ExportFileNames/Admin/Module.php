<?php

namespace App\Enums\ExportFileNames\Admin;

enum Module
{
    const EXPORT_CSV = 'Modules.csv';
    const EXPORT_XLSX = 'Modules.xlsx';
}
