<?php

namespace App\Enums\ExportFileNames\Admin;

enum Zone
{
    const EXPORT_CSV = 'Zones.csv';
    const EXPORT_XLSX = 'Zones.xlsx';
}
