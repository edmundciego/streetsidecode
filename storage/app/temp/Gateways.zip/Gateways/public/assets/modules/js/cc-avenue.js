'use strict';
document.redirect.submit();
