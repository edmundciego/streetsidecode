<?php

if (!defined('SOFTWARE_INFO')) {
    define('SOFTWARE_INFO', [
        [
            'software_id' => '33571750',
            'values' => [
                'name' => 'Stack Food',
                'addon_index_route' => 'admin.business-settings.system-addon.index',
            ]
        ],
        [
            'software_id' => '36772112',
            'values' => [
                'name' => '6am Mart',
                'addon_index_route' => 'admin.business-settings.system-addon.index'
            ]
        ],
        [
            'software_id' => '32791631',
            'values' => [
                'name' => 'Gro Fresh',
                'addon_index_route' => 'admin.system-addon.index'
            ]
        ],
        [
            'software_id' => '30320338',
            'values' => [
                'name' => 'eFood',
                'addon_index_route' => 'admin.system-addon.index'
            ]
        ],
        [
            'software_id' => '40224772',
            'values' => [
                'name' => 'Demandium',
                'addon_index_route' => 'admin.addon.index'
            ]
        ],
        [
            'software_id' => '31448597',
            'values' => [
                'name' => '6valley',
                'addon_index_route' => 'admin.addon.index'
            ]
        ],
        [
            'software_id' => '37354147',
            'values' => [
                'name' => '6cash',
                'addon_index_route' => 'admin.addon.index'
            ]
        ]
    ]);
}
